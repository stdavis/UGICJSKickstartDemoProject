﻿dojo.provide("ijit.widgets.notify.Feedback");

dojo.require('dijit._Widget');
dojo.require('dijit._Templated');
dojo.require('dijit.form.Button');
dojo.require('dijit.form.Form');
dojo.require('dojox.validate.regexp');
dojo.require('dijit.form.Textarea');
dojo.require('dijit.form.ValidationTextBox');
dojo.require('dojo.io.iframe');

dojo.declare("ijit.widgets.notify.Feedback", [dijit._Widget, dijit._Templated], {
    // summary:
    //		TODO: Put Summary here
    // description:
    //		TODO: Give a description
    // example:
    //      TODO: Give example

    templateString: dojo.cache('ijit.widgets.notify', 'templates/Feedback.htm'),

    widgetsInTemplate: true,

    map: {},
    titleText: 'We Encourage Feedback',
    emailText: 'Email Address',
    feedbackText: 'Issue',
    feedbackAreaText: "I love this map but something isn't right... ",
    buttonText: 'Report it',
    serviceName: 'Digital Utah!',
    url: "http://agrc-sgourley2/WSUT/Notify.svc/XFeedback",
    successText: 'Thanks, we really do appreciate and encourage your feedback!',
    errorText: 'Sorry something went wrong and we did not receive your feedback. You can send an email directly to mpeters@utah.gov.',

    constructor: function() { },

    postCreate: function()
    {
        this.TitleText.innerHTML=this.titleText;
        this.EmailText.innerHTML=this.emailText;
        this.FeedbackText.innerHTML=this.feedbackText;
        this.Feedback_Textarea.set('value', this.feedbackAreaText);
        this.Feedback_Submit.set('label', this.buttonText);
    },

    _clearMessage: function()
    {
        this.message.innerHTML="";
    },

    onCancel: function()
    {
        this.hide();
    },

    hide: function()
    {
        this._clearMessage();
        dojo.removeClass(this.widgetFeedback, ['widgetHidden', 'widgetVisible']);
        dojo.addClass(this.widgetFeedback, 'widgetHidden');
    },

    show: function()
    {
        this._clearMessage();
        dojo.removeClass(this.widgetFeedback, ['widgetHidden', 'widgetVisible']);
        dojo.addClass(this.widgetFeedback, 'widgetVisible');
    },

    determineMapLocation: function()
    {
        if (this.map instanceof esri.Map)
        {
            var extent=this.map.extent;
            var scale= -1;
            var layer={};
            var layerIds=this.map.layerIds;
            var _id= -1;

            if (dojo.some(layerIds, function(id)
            {
                layer=this.map.getLayer(id);
                var x=layer instanceof esri.layers.ArcGISTiledMapServiceLayer;
                return x;
            }, this))
            {
                scale=layer.tileInfo.lods[this.map.getLevel()].scale;
            }
            else
            {
                var dpi=96;
                var imageWidth=this.map.width;
                var imageHeight=this.map.height;
                var centerX=extent.xmax-(extent.xmax-extent.xmin)/2;
                var centerY=extent.ymax-(extent.ymax-extent.ymin)/2;
                var dpm=dpi/2.54*100;
                var width=(imageWidth/2)/dpm;

                scale=(extent.xmax-centerX)/width;
            }
        }

        return 'scale '+scale+' | LowerLeft '+extent.xmin+', '+extent.ymin+' | UpperRight '+extent.ymin+', '+extent.ymax;
    },

    submit: function(e)
    {
        if (this.validate())
        {
            this.Feedback_Submit.set('disabled', true);
            this._clearMessage();

            var email=this.Feedback_Email.value;
            var feedback=this.Feedback_Textarea.get('value');

            var json={ 'emailAddress': email, 'comment': feedback, 'serviceName': this.serviceName, 'location': this.determineMapLocation() };
            var request={ 'feedback': dojo.toJson(json) };

            var jsonpArgs={
                url: this.url,
                callbackParamName: "callback",
                content: request,
                load: dojo.hitch(this, function(result, ioArgs)
                {
                    this.form.reset();
                    dojo.addClass(dojo.create('div', { innerHTML: this.successText }, this.message), 'success');
                    this.Feedback_Submit.set('disabled', false);
                }),
                error: dojo.hitch(this, function(err)
                {
                    dojo.addClass(dojo.create('div', { innerHTML: this.errorText }, this.message), 'error');
                    this.Feedback_Submit.set('disabled', false);

                    if (err.status==404)
                    {
                        console.error("404 service not found");
                    }
                    else if (err.status==500)
                    {
                        console.error("500");
                    }
                }),
                timeout: 15000
            };
            dojo.io.script.get(jsonpArgs);
        }
    },

    validate: function()
    {
        this.form.validate();
        return this.form.isValid();
    }
});