/*global dojo, dijit, raster, console, rasterglobal*/
dojo.provide("raster.IdentifyResults");

dojo.declare('raster.IdentifyResults', null, {
    // one array for each layer
    // arrays are initialized in the constructor
    // arrays hold groups which, in turn, hold arrays of products
    0: null, // aerials
    1: null, // contours
    2: null, // dem's
    3: null, // lidar

    // layer example: 
    //
    // [
    //     // group
    //     {
    //         name: String (Category),
    //         date: Date,
    //         products: esri.Graphic[]
    //     }
    // ]
    
    constructor: function () {
        this['0'] = [];
        this['1'] = [];
        this['2'] = [];
        this['3'] = [];
    },
    add: function (result) {
        // summary:
        //      Adds a result to the appropriate layer and group
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        var atts = result.feature.attributes;
        var flds = rasterglobal.fields.common;
        var groupname = atts[flds.Category];

        // look for existing group and add to products
        var found = dojo.some(this[result.layerId], function (group) {
            if (group.name === groupname) {
                group.products.push(result.feature);
                return true;
            } else {
                return false;
            }
        }, this);

        // if no group found, then create new group
        if (!found) {
            this[result.layerId].push({
                name: groupname,
                date: new Date(atts[flds.Estimated_Date] + ' UTC'),
                products: [result.feature]
            });
        }
    },
    sort: function () {
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        function sortGroups(a, b) {
            if (a.date < b.date) {
                return 1;
            } else {
                return -1;
            }
        }

        // only sort photography
        this['0'].sort(sortGroups);
    }
});
