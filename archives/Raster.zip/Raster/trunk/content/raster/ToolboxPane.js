/*global dojo, dijit*/
dojo.provide("raster.ToolboxPane");

dojo.require("dijit.TitlePane");

dojo.declare('raster.ToolboxPane', [dijit.TitlePane], {
    toggle: function() {
        // summary:
        //      overriden to adjust for window height
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.inherited(arguments);
    }
});
