/*global dojo, console, dijit, ijit, agrc, raster, esri*/

// provide namespace
dojo.provide("raster.Toolbox");

// dojo widget requires
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");

// other dojo requires
dojo.require("ijit.widgets.layout.PaneStack");
dojo.require("raster.FindAddress");
dojo.require("dijit.form.CheckBox");
dojo.require("dijit.Toolbar");
dojo.require("raster.Search");
dojo.require("raster.ProductResult");
dojo.require('raster.ResultGroup');

dojo.declare("raster.Toolbox", [dijit._Widget, dijit._Templated], {
    // description:
    
    // widgetsInTemplate: [private] Boolean
    //      Specific to dijit._Templated.
    widgetsInTemplate: true,
    
    // templatePath: [private] String
    //      Path to template. See dijit._Templated
    templatePath: dojo.moduleUrl("raster", "templates/Toolbox.html"),
    
    // baseClass: [private] String
    //    The css class that is applied to the base div of the widget markup
    baseClass: "raster-toolbox",
    
    // drawToolbar: esri.toolbars.Draw
    drawToolbar: null,
    
    // drawingGraphics: esri.layers.GraphicsLayer
    drawingGraphics: null,
    
    // findAddress: raster.FindAddress
    findAddress: null,
    
    // pStack: ijit.widgets.layout.PaneStack
    pStack: null,
    
    // search: raster.Search
    search: null,
    
    // extentGraphics: esri.layers.GraphicsLayer
    extentGraphics: null,

    // resultsSymbol: esri.symbol.SimpleFillSymbol
    restulsSymbol: null,
    

    // Parameters to constructor

    // map: esri.Map
    map: null,
    
    constructor: function(params, div) {
        // summary:
        //    Constructor method
        // params: Object
        //    Parameters to pass into the widget. Required values include:
        // div: String|DomNode
        //    A reference to the div that you want the widget to be created in.
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
    },
    postCreate: function() {
        // summary:
        //    Overrides method of same name in dijit._Widget.
        // tags:
        //    private
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
    
        this.pStack = new ijit.widgets.layout.PaneStack(null, this.paneStack);
        this.pStack.startup();

        this.drawingGraphics = new esri.layers.GraphicsLayer();
        this.map.addLayer(this.drawingGraphics);

        this.findAddress = new raster.FindAddress({
            map: this.map,
            graphicsLayer: this.drawingGraphics,
            onFind: dojo.hitch(this, function() {
                this.drawingGraphics.clear();
            })
        }, 'find-address');
                    
        this.initDrawingToolbar();

        // this.resultsSymbol = dojo.clone(this.drawToolbar.fillSymbol).outline.setColor(new dojo.Color([255, 255, 0]));
        this.resultsSymbol = new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_NULL,
            new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
                new dojo.Color([255, 255, 0]), 3), null);
        
        this.search = new raster.Search({map: this.map});
        
        this._wireEvents();
        
        // couldn't get a dojoattachpoint to work with this. I'm guessing it's because
        // i have it jammed into a button widget
        this.searchImg = dojo.byId('searchImg');
        
        this.extentGraphics = new esri.layers.GraphicsLayer();
        this.map.addLayer(this.extentGraphics);
    },
    initDrawingToolbar: function(){
        // summary:
        //      Sets up the drawing toolbar
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.drawToolbar = new esri.toolbars.Draw(this.map);
        this.drawToolbar.setMarkerSymbol(this.findAddress.symbol);
    },
    _wireEvents: function() {
        // summary:
        //    Wires events.
        // tags:
        //    private
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.connect(this.drawToolbar, 'onDrawEnd', this.addDrawingToMap);
        dojo.forEach(this.dijitToolbar.getChildren(), function (w) {
            this.connect(w, 'onClick', this.onToolbarButtonClick);
        }, this);
        this.connect(this.searchBtn, 'onClick', this.onSearchClick);
        this.connect(this.search, 'onSearchComplete', this.searchComplete);
        this.subscribe(raster.ProductResult.prototype.downloadClickChannelName, this.onDownloadClick);
    },
    addDrawingToMap: function(geometry){
        // summary:
        //      Fires when the user completes a drawing
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.drawingGraphics.clear();
        
        // get symbol
        var sym;
        switch (geometry.type) {
            case 'point':
                sym = this.drawToolbar.markerSymbol;
                break;
            case 'polyline':
                sym = this.drawToolbar.lineSymbol;
                break;
            case 'polygon':
                sym = this.drawToolbar.fillSymbol;
                break;
        }
        
        var g = new esri.Graphic(geometry, sym);
        this.drawingGraphics.add(g);
    },
    onToolbarButtonClick: function(evt) {
        // summary:
        //      Fires when the user click a button on the toolbar.
        //      Activates the button with the esri.Toolbar and
        //      un-selects all other buttons.
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        var clickedButton = dijit.getEnclosingWidget(evt.currentTarget);
        
        // de-select all other buttons
        dojo.query('.raster-toolbox .draw-toolbar .icon').forEach(function (btn) {
            var widget = dijit.getEnclosingWidget(btn);
            if (widget.id !== clickedButton.id) {
                widget.set('checked', false);
            }
        });
        
        // activate tool
        this.drawToolbar.activate(esri.toolbars.Draw[clickedButton.get('value')]);
    },
    unselectAllTools: function () {
        // summary:
        //      unselects all tools on the toolbar
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);

        dojo.query('.raster-toolbox .draw-toolbar .icon').forEach(function (btn) {
            dijit.getEnclosingWidget(btn).set('checked', false);
        });
    },
    onSearchClick: function(evt){
        // summary:
        //      Fires when the user clicks the search button
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        // check to make sure that some search products are selected
        // check to make sure that a geometry is defined
        var checked = this.getSelectedLayerIds();
        
        if (checked.length === 0) {
            this.displaySearchWarning('Please select at least one data category check box in "Step 1 - Select Products"');
            return;
        } else if (this.drawingGraphics.graphics.length === 0) {
            this.displaySearchWarning('Please define an Area of Interest on the map using the tools above.');
            return;
        }
        
        this.searchBtn.set('disabled', true);
        dojo.removeClass(this.searchImg, 'hidden');
        this.hideSearchWarning();
        
        try {
            this.search.search(this.drawingGraphics.graphics[0].geometry, checked);
        } catch (er) {
            this.displaySearchWarning('There was an error with the search.');
            dojo.addClass(this.searchImg, 'hidden');
            this.searchBtn.set('disabled', false);
        }
    },
    getSelectedLayerIds: function(){
        // summary:
        //      Gets the ids of the layers that are checked in Step 1
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        var ids = [];
        dojo.query('.raster-toolbox .select-products input[aria-pressed=true]').forEach(function (chbx) {
            ids.push(chbx.value);
        });
        return ids;
    },
    searchComplete: function(results){
        // summary:
        //      description
        // results: raster.CustomIdentifyResults
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);

        results.sort();
        
        var checked = this.getSelectedLayerIds();
        
        dojo.addClass(this.noResults, 'hidden');
        
        // only display results containers that were not checked in "Select Products"
        dojo.query('.results-container').addClass('hidden');
        dojo.forEach(checked, function (id) {
            var rdiv = this[id + 'Results'];
            rdiv.innerHTML = ''; // TODO: this may not be the best way to clear the results

            dojo.removeClass(this[id + 'ResultsContainer'], 'hidden');

            if (results[id].length > 0) {
                // loop through groups
                dojo.forEach(results[id], function (result) {
                    var group = new raster.ResultGroup({
                        title: result.name
                    }, dojo.create('div', null, rdiv));

                    // loop through products within the group
                    dojo.forEach(result.products, function (prod) {
                        // show preview button for aerial photography only if there
                        // is a value for REST_Endpoint
                        var showPreview = (id === '0' && 
                            prod.attributes[rasterglobal.fields.common.REST_Endpoint] !== 'n/a');
                        prod.setSymbol(this.resultsSymbol);
                        var r = new raster.ProductResult({
                            title: prod.attributes[rasterglobal.fields.common.Product],
                            gLayer: this.extentGraphics,
                            graphic: prod,
                            showPreview: showPreview,
                            map: this.map
                        }, dojo.create('div', null, group.containerNode));
                    }, this);
                }, this);
            } else {
                rdiv.innerHTML = 'No data found.';
            }
        }, this);
        
        this.pStack.panes[2].toggle();
        
        dojo.addClass(this.searchImg, 'hidden');
        this.searchBtn.set('disabled', false);

        this.drawToolbar.deactivate();
        this.unselectAllTools();
    },
    displaySearchWarning: function(msg){
        // summary:
        //      shows the warning box and displays the text
        // msg: String
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.searchWarning.innerHTML = msg;
        
        dojo.removeClass(this.searchWarning, 'hidden');
    },
    hideSearchWarning: function () {
        // summary:
        //      hides the box
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        dojo.addClass(this.searchWarning, 'hidden');
    },
    onDownloadClick: function (something) {
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.pStack.panes[3].toggle();
    }
});