/*global dojo, console, dijit*/

// provide namespace
dojo.provide("raster.ProductResult");

// other dojo requires
dojo.require("dijit.TitlePane");
dojo.require('dijit.form.ToggleButton');

dojo.declare("raster.ProductResult", [dijit.TitlePane], {
    // description:
    //      Mixin for DataCategory_Search and DataCategory_Results
    
    // widgetsInTemplate: [private] Boolean
    //      Specific to dijit._Templated.
    widgetsInTemplate: true,
    
    templateString: dojo.cache("raster", "templates/ProductResult.html"),
    
    // baseClass: [private] String
    //    The css class that is applied to the base div of the widget markup
    baseClass: "product-result",
    
    // buttonClick: Boolean
    //      Used to prevent the pane from toggling when clicking on the extent
    //      or preview buttons
    buttonClick: false,

    // previewClickChannelName: String
    previewClickChannelName: 'raster.ProductResult.onPreviewClick',

    // downloadClickChannelName: String
    downloadClickChannelName: 'raster.ProductResult.onDownloadClick',

    // previewLyr: esri.layers.ArcGISImageServiceLayer
    previewLyr: null,
    

    // Parameters to constructor
    
    // title: String
    
    // gLayer: esri.layers.GraphicsLayer
    gLayer: null,
    
    // graphic: esri.Graphic
    graphic: null,

    // showPreview: Boolean
    //      Determines whether or not to show the preview button
    //      Only shown for aerial photography
    showPreview: false,

    // map: esri.Map
    map: null,
    
    constructor: function(params, div) {
        // summary:
        //    Constructor method
        // params: Object
        //    Parameters to pass into the widget. Required values include:
        // div: String|DomNode
        //    A reference to the div that you want the widget to be created in.
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
    },
    postCreate: function() {
        // summary:
        //    Overrides method of same name in dijit._Widget.
        // tags:
        //    private
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
    
        this._wireEvents();
        
        this.inherited(arguments);
        
        // doing it this way prevents the animation from happening
        this.set('open', false);

        // show preview button
        if (this.showPreview) {
            dojo.removeClass(this.previewBtn.domNode, 'hidden');
        }

        dojo.place(this.innerContent, this.containerNode);

        this.buildContent();
    },
    buildContent: function () {
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);

        // var lst = dojo.create('ul', null);
        // dojo.create('li', {
        //     innerHTML: this.graphic.attributes[rasterglobal.fields.common.File_Format]
        // }, lst);
        
        // this.set('content', 'A few key attributes');
        this.link.href = this.graphic.attributes[rasterglobal.fields.common.HTML_Page];
    },
    _wireEvents: function() {
        // summary:
        //    Wires events.
        // tags:
        //    private
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.connect(this.previewBtn, 'onClick', this.onPreviewClick);
        this.connect(this.domNode, 'onmouseenter', this.onMouseEnter);
        this.connect(this.domNode, 'onmouseleave', this.onMouseLeave);
        this.subscribe(this.previewClickChannelName, function () {
            if (!this.buttonClicked) {
                this.previewBtn.set('checked', false);
                if (this.previewLyr) {
                    this.previewLyr.hide();
                }
            }
        });
        this.connect(this.downloadBtn, 'onClick', this.onDownloadClick);
    },
    onPreviewClick: function(evt){
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.preventToggle(evt);

        if (!this.previewLyr) {
            this.addLayer();
        } else {
            this.previewLyr.setVisibility(this.previewBtn.get('checked'));
        }

        dojo.publish(this.previewClickChannelName);
    },
    addLayer: function () {
        // summary:
        //      addes the image service layer to the map
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        var params = new esri.layers.ImageServiceParameters();
        params.bandIds = [0,1,2];
        params.format = 'jpg';
        var url = this.graphic.attributes[rasterglobal.fields.common.REST_Endpoint];
        this.previewLyr = new esri.layers.ArcGISImageServiceLayer(url, {
            imageServiceParameters: params
        });
        this.map.addLayer(this.previewLyr);
        this.map.addLoaderToLayer(this.previewLyr);
    },
    preventToggle: function(evt){
        // summary:
        //      Prevents the title pane from toggling
        // evt: Event{}
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);

        this.buttonClicked = true;
        evt.stopPropagation();
    },
    _onTitleClick: function(evt){
        // summary:
        //      Overridden to check to see if a button was clicked.
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        if (!this.buttonClicked) {
            this.inherited(arguments);
        } else {
            this.buttonClicked = false;
        }
    },
    onMouseEnter: function(){
        // summary:
        //      description
        // console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        // // if the geometry of the graphic contains the entire map extent, don't display it
        // // this is to prevent confusion when the entire map is overlayed by the graphic
        // var ex = this.map.extent;
        // var tl = new esri.geometry.Point([ex.xmin, ex.ymax], this.map.spatialReference);
        // var bl = new esri.geometry.Point([ex.xmin, ex.ymin], this.map.spatialReference);
        // var tr = new esri.geometry.Point([ex.xmax, ex.ymax], this.map.spatialReference);
        // var br = new esri.geometry.Point([ex.xmax, ex.ymin], this.map.spatialReference);
        // var geo = this.graphic.geometry;
        // if (!geo.contains(tl) ||
        //     !geo.contains(bl) ||
        //     !geo.contains(tr) ||
        //     !geo.contains(br)) {
            this.gLayer.add(this.graphic);
        // }
    },
    onMouseLeave: function(){
        // summary:
        //      description
        // console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.gLayer.clear();
    },
    destroy: function () {
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        if (this.previewLyr) {
            this.map.removeLayer(this.previewLyr);
        }

        this.inherited(arguments);
    },
    onDownloadClick: function (evt) {
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        dojo.publish(this.downloadClickChannelName);
    }
});