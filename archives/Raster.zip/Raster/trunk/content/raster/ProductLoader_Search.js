dojo.provide("raster.ProductLoader_Search");

// dojo.require("raster.DataCategory_Search");

dojo.declare("raster.ProductLoader_Search", null, {
    // summary:
    //      Loads the map service layer and gets the layers and data products
    
    // lyr: esri.layers.ArcGISDynamicMapServiceLayer
    lyr: null,
    
    constructor: function() {
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.lyr = new esri.layers.ArcGISDynamicMapServiceLayer(rasterglobal.urls.mapService);
        dojo.connect(this.lyr, 'onLoad', this, 'layerLoaded');
    },
    layerLoaded: function(){
        // summary:
        //      Fires when the layer has been loaded.
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        this.initDataTypes();
    },
    initDataTypes: function(){
        // summary:
        //      description
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        var fields = rasterglobal.fields.common;
        var that = this;
        
        var query = new esri.tasks.Query();
        query.outFields = [fields.Product, fields.REST_Endpoint, fields.Estimated_Date];
        query.where = '1 = 1';
        // query.orderByFields = [fields.Estimated_Date + ' DESC']; // available at 10.1
        
        // build array of query tasks that need to be fired sequentially instead
        // of hitting the server all at the same time.
        var tasks = dojo.map(this.lyr.layerInfos, function (info) {
            var cat = new raster.DataCategory_Search({
                title: info.name
            }, dojo.create('div', null, 'dataCategories'));
            
            var qTask = new esri.tasks.QueryTask(that.lyr.url + '/' + info.id);
            return {
                task: qTask,
                onLoad: function(response) {
                    if (response.features.length === 0) {
                        onError({message: 'No products found!'});
                    } else {
                        that.loadDataProducts(response.features, cat);
                    }
                }
            };
        });
        
        var i = 0;
        function fireQuery(task) {
            task.task.execute(query, function(response) {
                task.onLoad(response);
                i = i + 1;
                if (i < tasks.length) {
                    fireQuery(tasks[i])
                }
            }, onError);
        }
        
        function onError(er) {
            console.log("ERROR: ", er);
        }
        
        fireQuery(tasks[0])
    },
    loadDataProducts: function(features, dataCategory){
        // summary:
        //      load data products into associated data type
        // features: esri.Graphic[]
        //      As returned from the query task
        // dataCategory: raster.DataCategory_Search
        //      The id of the node within which the product widgets should be placed.
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        var fields = rasterglobal.fields.common;
        
        // order from newest to oldest
        function sort(a, b) {
            if (a.attributes[fields.Estimated_Date] < b.attributes[fields.Estimated_Date]) {
                return 1;
            } else {
                return -1;
            }
        }
        features.sort(sort);
        
        var existingProducts = []; // used to remove duplicates
        dojo.forEach(features, function (f) {
            var prod = f.attributes[fields.Product];
            
            if (dojo.indexOf(existingProducts, prod) === -1 &&
                prod !== 'n/a') {
                var params = {
                    productTitle: prod,
                    displayPreview: f.attributes[fields.REST_Endpoint] !== 'n/a'
                };
                dataCategory.addProduct(params);
                existingProducts.push(prod);
            }
        });
        
        // we want this closed on startup. If I use toggle you could see the end
        // of the animation as the page finished loading. .set(..) doesn't seem
        // to use the animation
        dataCategory.set('open', false);
    }
});