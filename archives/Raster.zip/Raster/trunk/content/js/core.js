/*global dojo, console, agrc, ijit, dijit, raster*/
dojo.provide("js.core");

dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("agrc.widgets.map.BaseMap");
dojo.require("agrc.widgets.map.BaseMapSelector");
dojo.require("raster.Toolbox");
dojo.require("dijit.Toolbar");
dojo.require("raster.ProductLoader_Search");
dojo.require("raster.ToolboxPane");

var rasterapp;
dojo.declare("rasterapp", null, {
    // map: agrc.widgets.map.BaseMap
    map: null,
    
	constructor: function () {
		// summary:
		//		first function to fire after page loads
		console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
		
		// global reference
		rasterapp = this;
		
		this.initMap();
		
		var toolbox = new raster.Toolbox({map: this.map}, 'raster-toolbox');
		
		// this.pLoader = new raster.ProductLoader_Search();
		
		this.wireEvents();
	},
	initMap: function(){
		// summary:
		//      description
		console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
		
		this.map = new agrc.widgets.map.BaseMap('map-div', {
		    useDefaultBaseMap: false
		});
		
		var selector = new agrc.widgets.map.BaseMapSelector({
		    map: this.map,
		    id: 'claro',
		    position: 'BL'
		});
	},
	wireEvents: function(){
	   console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
	   
	   dojo.connect(this.map, 'onLoad', this, 'hideLoadingOverlay');
	},
	hideLoadingOverlay: function(){
        // summary:
        //      fades out the loader overlay
        console.info(this.declaredClass + "::" + arguments.callee.nom, arguments);
        
        dojo.fadeOut({
            node: 'loading-overlay',
            onEnd: function(n) {
                dojo.style(n, 'display', 'none');
            }
        }).play();
    }
});

dojo.ready(function(){
	var app = new rasterapp();
});