var djConfig={
	isDebug: true, // remove for build
	debugAtAllCosts: true, // remove for build
	baseUrl: "./", // remove for build
	modulePaths: { // remove for build
		"agrc": "./content/agrc",
		"ijit": "./content/ijit", 
		'raster': './content/raster'
	},
	parseOnLoad: true
};
var rasterglobal = {
	urls: {
		mapService: '/ArcGIS/rest/services/Raster/MapServer'
	},
	fields: {
		common: {
			Category: 'Category',
			Product: 'Product',
			REST_Endpoint: 'REST_Endpoint',
			Estimated_Date: 'Estimated_Date',
			OBJECTID: 'OBJECTID',
			Description: 'Description',
			File_Format: 'File_Format',
			In_House: 'In_House',
			HTML_Page: 'HTML_Page',
			Average_File_Size: 'Average_File_Size',
			Horizontal_Accuracy: 'Horizontal_Accuracy',
			Contact: 'Contact',
			FTP_Path: 'FTP_Path',
			Tile_Index: 'Tile_Index'
		}
	}
};