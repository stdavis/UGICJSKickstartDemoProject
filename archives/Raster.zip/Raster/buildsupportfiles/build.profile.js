dependencies = {
	cssOptimize: "comments",
	optimize: "shrinksafe",
	layerOptimize: "shrinksafe",
	action: "clean,release",
	version: "1.6.1src",
	internStrings: true,
	mini: true,
	stripConsole: "all",
	releaseName: "Raster/content",
    localeList: 'en-us',
	layers: [
		{
			name: "esriapi.discard",
			resourceName: "esriapi.discard",
			discard: true,
			dependencies: [
				"dijit.WidgetSet",
				"dojo.fx.Toggler",
				"dojo.Stateful",
				"dijit._WidgetBase",
				"dijit._Widget",
				"dijit._Templated",
				"dijit._Container",
				"dijit._CssStateMixin",
				"dijit.form._FormWidget",
				"dijit.form._FormValueWidget",
				"dojo.dnd.Mover",
				"dojo.dnd.Moveable",
				"dojo.dnd.move.constrainedMoveable",
				"dojo.dnd.move.boxConstrainedMoveable",
				"dojo.dnd.move.parentConstrainedMoveable",
				"dijit._HasDropDown",
				"dijit.form.Button",
				"dijit.form.DropDownButton",
				"dijit.form.ComboButton",
				"dijit.form.ToggleButton",
				"dijit.form.HorizontalSlider",
				"dijit.form._SliderMover",
				"dijit.form.VerticalSlider",
				"dijit.form.HorizontalRule",
				"dijit.form.VerticalRule",
				"dijit.form.HorizontalRuleLabels",
				"dijit.form.VerticalRuleLabels"
			]
		},
		{
			name: "../RasterLyr.js",
			resourceName: "RasterLyr",
			layerDependencies: [
				"esriapi.discard"
			],
			dependencies: [
				"js.core"
			]
		}
	],
	prefixes: [
		["agrc", "../../../Raster/trunk/content/agrc"],
		["css", "../../../Raster/trunk/content/css"],
		["data", "../../../Raster/trunk/content/data"],
		["html", "../../../Raster/trunk/content/html"],
		["ijit", "../../../Raster/trunk/content/ijit"],
		["images", "../../../Raster/trunk/content/images"],
		["js", "../../../Raster/trunk/content/js"],
		['raster', '../../../Raster/trunk/content/raster'],
		['dojox', '../dojox'],
		["dijit", "../dijit"]
	]
}