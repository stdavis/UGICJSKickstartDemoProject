console.log('hello');

function init() {
    console.log('init fired');
}